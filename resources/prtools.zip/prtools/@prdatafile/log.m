%LOG Datafile overload
