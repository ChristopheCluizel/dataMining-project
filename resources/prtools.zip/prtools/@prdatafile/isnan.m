%ISNAN Datafile overload
