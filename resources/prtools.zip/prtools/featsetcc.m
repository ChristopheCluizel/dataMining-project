%FEATSETCC Feature set combining classifier

% Copyright: R.P.W. Duin, r.p.w.duin@37steps.com
% Faculty EWI, Delft University of Technology
% P.O. Box 5031, 2600 GA Delft, The Netherlands

function [dset,id] = featsetcc(dobj,combc)

error('featsetcc has been replaced by bagcc')